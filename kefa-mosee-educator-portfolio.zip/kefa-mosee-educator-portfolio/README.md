# Kefa Mosee | Educator Portfolio 

A Pen created on CodePen.

Original URL: [https://codepen.io/kefa-mosee/pen/myOPPjv](https://codepen.io/kefa-mosee/pen/myOPPjv).

